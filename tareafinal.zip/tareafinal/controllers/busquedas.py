# -*- coding: utf-8 -*-


# Búsqueda de centros por codigo_cias, codigo_gap, nombre, teléfonos
# Búsqueda de consultorios por codigo_cias, codigo_gap, nombre, teléfonos
# Busqueda de rangos por nombre y descripción
# Búsqueda de ip
# Búsqueda de ips libres de un centro/consultorio
# Búsqueda de puestos por ip, nombre, teléfono, profesional

#celtro1
# centro2
# centro3

#/tareafinal/busquedas/centro_por_codigo_cias/<codigo_cias>
def centro_por_codigo_cias():
    'devuelve el centro con un codigo_cias'
    #primer recoger el argumento
    #despues hacer la selecion
    #mostarlo selecionado
    rango=db(db.rango).select(db.rango.ALL)
    return dict(rango=rango)