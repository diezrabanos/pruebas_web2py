from mimodulo import sacaips

# Categorías
#-codigo_cias(string de 8, único y no vacío) 17050010, 17050110, 17050210, ...
#-codigo_gap(string de 2, único y no vacío) 00, 01, 02, ...
#-nombre(string de 18, no vacío)
#-direccion(string de 50, no vacía)
#-telefono_fijo(string de 12, no vacío)
#-telefono_urgencias(string de 12)
#-telefono_movil(string de 12)
#-notas(texto largo)
db.define_table('centro',
  Field('codigo_cias', unique=True,type='string',length=8,requires=(IS_NOT_EMPTY())),
  Field('codigo_gap',unique=True, requires=IS_NOT_EMPTY(), type='string',length=2),
  Field('nombre', requires=IS_NOT_EMPTY(), type='string',length=18),
  Field('direccion', requires=IS_NOT_EMPTY(), type='string',length=50),
  Field('telefono_fijo', requires=IS_NOT_EMPTY(), type='string',length=12),
  Field('telefono_urgencias', type='string',length=12),
  Field('telefono_movil', type='string',length=12),
  Field('notas', type='text'))

  

# consultorio
# -centro(referencia de centro)
# -codigo_cias(string de 8, único y no vacío) 17050020, 17050021, 17050022, ...
# -codigo_gap(string de 4, único y no vacío) 0020, 0021, 0022, ...
# -nombre(string de 30, no vacío)
# -direccion(string de 50, no vacía)
# -telefono_fijo(string de 12, no vacío)
# -notas(texto largo)

db.define_table('consultorio',
                Field('centro','reference centro',requires=IS_IN_DB(db,'centro.id','%(nombre)s')),
                Field('codigo_cias', unique=True,requires=IS_NOT_EMPTY(), type='string',length=8),
                Field('codigo_gap',unique=True, requires=IS_NOT_EMPTY(), type='string',length=4),
                Field('nombre', requires=IS_NOT_EMPTY(), type='string',length=30),
                Field('direccion', requires=IS_NOT_EMPTY(), type='string',length=8),
                Field('telefono_fijo', requires=IS_NOT_EMPTY(), type='string',length=12),
                Field('notas', type='text'))

# rango (rangos de red: 10.1.0.0/24)
# -nombre(string de 20, único y no vacío) 10.1.0.0/24
# -centro(referencia de centro)
# -consultorio(referencia de consultorio)
# -descripcion(string de 50) (impresoras, pcs, dhcp, etc)
# -inicio(string de 15 ipv4, no vacío) primera ip del rango
# -mascara(string de 15 ipv4, no vacío) máscara de red
# -fin(string de 15 ipv4, no vacío) última ip del rango
# -broadcast(string de 15 ipv4, no vacío)
# -notas(texto largo)

db.define_table('rango',
                Field('nombre', unique=True, requires=IS_NOT_EMPTY(), type='string',length=20),
                Field('centro','reference centro',requires=IS_IN_DB(db,'centro.id','%(nombre)s')),
                Field('consultorio', 'reference consultorio',requires=IS_IN_DB(db,'consultorio.id','%(nombre)s')),
                Field('descripcion', type='string',length=50),
                Field('inicio', requires=IS_NOT_EMPTY(), type='string',length=15),
                Field('mascara', requires=IS_NOT_EMPTY(), type='string',length=15),
                Field('fin', requires=IS_NOT_EMPTY(), type='string',length=15),
                Field('broadcast', requires=IS_NOT_EMPTY(), type='string',length=15),
                Field('notas', type='text'))#,
                #Field('ips', type='list:string',compute=lambda r: sacaips(r.inicio,r.fin),readable=False)
                #Field('ips_libres', type='list:string',compute=lambda r:  db.ip(r.rango).nombre)
                #Field('ips_libres', type='list:string',compute=lambda r: sacaipslibres(r))
                #)
                

# ip
# -rango(referencia a rango)
# -nombre(string de 15 ipv4, único, no vacío) 10.1.0.1
# -libre (sí o no, por defecto todas las ips están libres)

db.define_table('ip',
                 Field('rango','reference rango',requires=IS_IN_DB(db,'rango.id','%(nombre)s')),
                 Field('nombre',unique=True, requires=IS_NOT_EMPTY(), type='string',length=15),
                 Field('libre',type='boolean', default=True))

# puesto
# -centro(referencia a centro)
# -consultorio(referencia a consultorio)
# -ip(referencia a ip)
# -nombre(string de 20) urgencias 1, enfermería 1, pediatría, ...
# -telefono(string de 12)
# -profesional(string de 50)
# -notas(texto largo)


db.define_table('puesto',
                Field('centro', 'reference centro',requires=IS_IN_DB(db,'centro.id','%(nombre)s')),
                Field('consultorio', 'reference consultorio',requires=IS_IN_DB(db,'consultorio.id','%(nombre)s')),
                Field('ip','reference ip',requires=IS_IN_DB(db,'ip.id','%(nombre)s') ),
                Field('nombre', type='string',length=20),
                Field('telefono', type='string',length=12),
                Field('profesional', type='string',length=50),
                Field('notas', type='text'))




# función de utilidad
def author(user_id):
    if user_id:
        user = db.auth_user(user_id)
        if user:
            return A('{first_name} {last_name}'.format(**user),
                     _href=URL('list_posts_by_author', args=user.id))
        else:
            return 'Desconocido'
    else:
        return 'Desconocido'


# relleno las tablas para tener datos con los que trabajar
# from gluon.contrib.populate import populate

# if db(db.category).count() == 0:
#     db.category.insert(name='viajes')
#     db.category.insert(name='python')
#     db.category.insert(name='cocina')
#     db.category.insert(name='música')
#     db.commit()

# if db(db.auth_user).count() < 2:
#     populate(db.auth_user, 100)
#     db.commit()

# if db(db.post).count() < 2:
#     populate(db.post, 500)
#     db.commit()

# if db(db.comm).count() < 2:
#     populate(db.comm, 1000)
#     db.commit()
