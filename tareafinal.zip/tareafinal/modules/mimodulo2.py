#funcion
def sacaipslibres(r):
    'devuelve una lista con todas las ips libres de un rango'
    lista_ips_libres=[]
    lista_ips=r."ips"
    for i in lista_ips:
        resultado=db(db.ip.nombre==i).select(ip.nombre)
        lista_ips_libres.append(resultado)
    return lista_ips_libres


        

