#funcion
def sacaips(ip_inicial,ip_final):
    'devuelve una lista con todas las ips de un rango'

    lista_ips=[]
    a,b,c,d=ip_inicial.split('.')
    e=ip_final.split('.')[-1]
    #print(a,b,c,d,e)
    for i in list(range(int(d),int(e)+1)):
        constructor=(str(a),str(b),str(c),str(i))
        ip='.'.join(constructor)
        lista_ips.append(ip)
    return lista_ips


        

